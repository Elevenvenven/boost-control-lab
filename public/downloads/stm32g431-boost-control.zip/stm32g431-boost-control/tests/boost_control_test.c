#include "boost_control.h"

#include <assert.h>
#include <math.h>
#include <stdio.h>

static BoostConfig test_config(void)
{
    BoostConfig config = Boost_ConfigSafeDefaults();

    config.control_period_s = 0.001f;
    config.target_output_v = 24.0f;
    config.input_uvlo_v = 7.0f;
    config.output_ovp_v = 27.0f;
    config.current_limit_a = 4.0f;
    config.temperature_limit_c = 90.0f;
    config.minimum_duty = 0.02f;
    config.maximum_duty = 0.80f;
    config.duty_slew_rate_per_s = 2.0f;
    config.soft_start_time_s = 0.10f;
    config.proportional_gain = 0.015f;
    config.integral_gain_per_s = 2.0f;
    return config;
}

static void test_invalid_configuration_is_safe(void)
{
    BoostController controller;
    BoostConfig config = test_config();

    config.maximum_duty = INFINITY;
    Boost_Init(&controller, &config);

    const BoostOutput output = Boost_GetOutput(&controller);
    assert(output.state == BOOST_STATE_FAULT);
    assert((output.faults & BOOST_FAULT_CONFIG) != 0U);
    assert(!output.pwm_enabled);
    assert(output.duty == 0.0f);
    assert(!Boost_Start(&controller));
}

static void test_soft_start_and_latched_fault(void)
{
    BoostController controller;
    const BoostConfig config = test_config();
    const BoostMeasurements nominal = {
        .input_v = 12.0f,
        .output_v = 12.0f,
        .inductor_current_a = 1.0f,
        .temperature_c = 25.0f,
    };

    Boost_Init(&controller, &config);
    assert(Boost_Start(&controller));

    BoostOutput output = Boost_Step(&controller, &nominal);
    assert(output.state == BOOST_STATE_SOFT_START);
    assert(output.reference_v > 0.0f);
    assert(output.pwm_enabled);
    assert(output.duty <= config.duty_slew_rate_per_s *
                              config.control_period_s);

    for (int step = 0; step < 110; ++step)
    {
        output = Boost_Step(&controller, &nominal);
    }
    assert(output.state == BOOST_STATE_RUNNING);
    assert(fabsf(output.reference_v - config.target_output_v) < 0.001f);
    assert(output.duty >= config.minimum_duty);
    assert(output.duty <= config.maximum_duty);

    const BoostMeasurements overvoltage = {
        .input_v = 12.0f,
        .output_v = 28.0f,
        .inductor_current_a = 1.0f,
        .temperature_c = 25.0f,
    };
    output = Boost_Step(&controller, &overvoltage);
    assert(output.state == BOOST_STATE_FAULT);
    assert((output.faults & BOOST_FAULT_OUTPUT_OVP) != 0U);
    assert(!output.pwm_enabled);
    assert(output.duty == 0.0f);

    output = Boost_Step(&controller, &nominal);
    assert(output.state == BOOST_STATE_FAULT);
    assert((output.faults & BOOST_FAULT_OUTPUT_OVP) != 0U);

    assert(Boost_ClearFaults(&controller));
    output = Boost_GetOutput(&controller);
    assert(output.state == BOOST_STATE_OFF);
    assert(output.faults == BOOST_FAULT_NONE);
    assert(!output.pwm_enabled);
}

static void test_sensor_and_current_faults(void)
{
    BoostController controller;
    const BoostConfig config = test_config();
    BoostMeasurements measurements = {
        .input_v = 12.0f,
        .output_v = 12.0f,
        .inductor_current_a = 5.0f,
        .temperature_c = 25.0f,
    };

    Boost_Init(&controller, &config);
    assert(Boost_Start(&controller));

    BoostOutput output = Boost_Step(&controller, &measurements);
    assert((output.faults & BOOST_FAULT_OVERCURRENT) != 0U);
    assert(!output.pwm_enabled);

    assert(Boost_ClearFaults(&controller));
    assert(Boost_Start(&controller));
    measurements.inductor_current_a = 1.0f;
    measurements.output_v = NAN;

    output = Boost_Step(&controller, &measurements);
    assert((output.faults & BOOST_FAULT_BAD_SAMPLE) != 0U);
    assert(!output.pwm_enabled);
}

int main(void)
{
    test_invalid_configuration_is_safe();
    test_soft_start_and_latched_fault();
    test_sensor_and_current_faults();
    puts("boost_control_test: all tests passed");
    return 0;
}
